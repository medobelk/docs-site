<?php
return array(
    'app_name'=>'vostok',
    'db' => array(
        'dialect'  => 'mysql',
        'host'     => 'db7.unlim.com',
        'name'=> 'u5852_qa',
        'user_name'    => 'u5852_qa',
        'password' => 'qa12ws34',
        'encoding' => 'utf8',
        'sqlDebug' =>false
    ),
    'base_url' => 'http://docurolog.od.ua',
    'public_path' => 'app/public',
    'helpdesk-email' => 'help@mail.ru',
    'encoding' => 'utf-8',
    'debug' => true,

    'user_name' => 'admin',
    'password' => 'qa12ws34'

);
